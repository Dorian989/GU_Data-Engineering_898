-- Повторяем пройденый материал с 5 урока

CREATE TABLE catalogs;

SELECT * FROM catalogs c ;

CREATE TABLE users (
id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY COMMENT "Идентификатор строки", 
name VARCHAR(100) NOT NULL COMMENT "Имя пользователя",
birthday_at VARCHAR(100)
);

SELECT * FROM users;


INSERT INTO users (name, birthday_at) VALUES
  ('Геннадий', '1990-10-05'),
  ('Наталья', '1984-11-12'),
  ('Александр', '1985-05-20'),
  ('Сергей', '1988-02-14'),
  ('Иван', '1998-01-12'),
  ('Мария', '1992-08-29');

SELECT * FROM users WHERE birthday_at >= '1990-01-01' AND birthday_at < '2000-01-01';

SELECT * FROM users WHERE birthday_at LIKE '199%';

SELECT 'программирование' RLIKE '^грам', 'граммпластинка' RLIKE '^грам';

SELECT 'грампластинка' RLIKE  '^граммпластинка$';

SELECT 'a' RLIKE '[abc]' AS 'a',
       'b' RLIKE '[abc]' AS 'b',
       'w' RLIKE '[abc]' AS 'w';
      
SELECT 'г' RLIKE '[а-яё]';

SELECT '7' RLIKE '[0-9]';


SELECT 7 RLIKE '[[:digit:]]', 'hello' RLIKE '[[:digit:]]';

SELECT '1' RLIKE '^[0-9]+$' AS '1',
       '34234' RLIKE '^[0-9]+$' AS '43234',
       '342.34' RLIKE '^[0-9]+$' AS '342.34',
       '' RLIKE '^[0-9]+$' AS '';
      
      
      
SELECT '342.34' RLIKE '^[0-9]*\\.[0-9]{2}$' AS '342.34';

SELECT * FROM catalogs;

SELECT * FROM catalogs c ORDER BY name;
SELECT * FROM catalogs c ORDER BY name DESC;

SELECT * FROM products p;

SELECT id, catalog_id, price, name FROM products p ;

SELECT id, catalog_id, price, name FROM products p ORDER BY catalog_id, price;
SELECT id, catalog_id, price, name FROM products p ORDER BY catalog_id, price DESC;
SELECT id, catalog_id, price, name FROM products p ORDER BY catalog_id DESC, price DESC;


SELECT id, catalog_id, price, name FROM products LIMIT 2 ;
SELECT id, catalog_id, price, name FROM products LIMIT 4, 2 ;
SELECT id, catalog_id, price, name FROM products LIMIT 2 OFFSET 4;

SELECT catalog_id FROM products p ORDER BY catalog_id;
SELECT DISTINCT catalog_id FROM products p ORDER BY catalog_id;

SELECT id, catalog_id, price, name FROM products p WHERE catalog_id = 2 AND price > 5000;

UPDATE products SET price = price * 0.9 WHERE catalog_id = 2 AND price > 5000;

SELECT id, catalog_id, price, name FROM products ORDER BY price;
SELECT id, catalog_id, price, name FROM products ORDER BY price DESC;
SELECT id, catalog_id, price, name FROM products ORDER BY price DESC LIMIT 2;
DELETE FROM products ORDER BY price DESC LIMIT 2;
SELECT id, catalog_id, price, name FROM products ORDER BY price DESC;

SELECT NOW();


INSERT INTO users VALUES (NULL, 'Геннадий','1990-1-05', NOW(), NOW());
DELETE FROM users WHERE id = 21;

SELECT name, created_at, updated_at FROM users WHERE name = 'Александр';
SELECT name, DATE(created_at), DATE(updated_at) FROM users WHERE name = 'Александр';

SELECT DATE_FORMAT(NOW(), 'На дворе %Y год'); 


SELECT id, SUBSTRING(name, 1, 5) AS name FROM users; 
SELECT id, CONCAT(name, ' ', TIMESTAMPDIFF(YEAR, birthday_at, NOW())) AS name FROM users;


SELECT  name, IF (TIMESTAMPDIFf(YEAR, birthday_at, NOW()) >= 18, 'совершеннолетний', 'несовершеннолетний') AS status FROM users;

CREATE TABLE rainbow (
  id SERIAL PRIMARY KEY,
  color VARCHAR(255)
) COMMENT = 'Цвета радуги';

INSERT INTO
  rainbow (color)
VALUES
  ('red'),
  ('orange'),
  ('yellow'),
  ('green'),
  ('blue'),
  ('indigo'),
  ('violet');
 
 SELECT
  CASE
    WHEN color = 'red' THEN 'красный'
    WHEN color = 'orange' THEN 'оранжевый'
    WHEN color = 'yellow' THEN 'желтый'
    WHEN color = 'green' THEN 'зеленый'
    WHEN color = 'blue' THEN 'голубой'
    WHEN color = 'indigo' THEN 'синий'
    ELSE 'фиолетовый'
  END AS russian
FROM
  rainbow;
 
 
SELECT INET_ATON('62.145.69.10'), INET_ATON ('127.0.0.1');
SELECT INET_NTOA('1049707786'), INET_NTOA('2130706433');
 
SELECT UUID();

SELECT  DISTINCT catalog_id FROM products;


SELECT id, name, id % 3 FROM products p ORDER BY id % 3;


SELECT catalog_id FROM products p GROUP BY catalog_id;

SELECT id, name, birthday_at FROM users;

SELECT id, name, SUBSTRING(birthday_at, 1, 3) FROM users; 

SELECT id, name, SUBSTRING(birthday_at, 1, 3) AS decade FROM users; 

SELECT id, name, SUBSTRING(birthday_at, 1, 3) AS decade FROM users ORDER BY decade;
SELECT  SUBSTRING(birthday_at, 1, 3) AS decade FROM users GROUP BY decade;

SELECT COUNT(*), SUBSTRING(birthday_at, 1, 3) AS decade FROM users GROUP BY decade;

SELECT COUNT(*), SUBSTRING(birthday_at, 1, 3) AS decade FROM users GROUP BY decade ORDER BY decade DESC;

SELECT COUNT(*) AS total, SUBSTRING(birthday_at, 1, 3) AS decade FROM users GROUP BY decade ORDER BY total DESC;


SELECT  GROUP_CONCAT(name), SUBSTRING(birthday_at, 1, 3) AS decade FROM users GROUP BY decade;

SELECT  GROUP_CONCAT(name  SEPARATOR ' '), SUBSTRING(birthday_at, 1, 3) AS decade FROM users GROUP BY decade;

SELECT  GROUP_CONCAT(name ORDER BY name DESC SEPARATOR ' '), SUBSTRING(birthday_at, 1, 3) AS decade FROM users GROUP BY decade;

SELECT COUNT(id) FROM catalogs;

SELECT COUNT(*) FROM catalogs;

SELECT catalog_id FROM products;

SELECT catalog_id FROM products GROUP BY catalog_id;

SELECT catalog_id, COUNT(*) AS total FROM products GROUP BY catalog_id;

CREATE TABLE tbl (
  id INT NOT NULL,
  value INT DEFAULT NULL
);

INSERT INTO tbl VALUES (1, 230);
INSERT INTO tbl VALUES (2, NULL);
INSERT INTO tbl VALUES (3, 405);
INSERT INTO tbl VALUES (4, NULL);

SELECT * FROM tbl;

SELECT value, COUNT(*) AS total FROM tbl GROUP BY  value;

SELECT COUNT(DISTINCT id) AS total_ids, COUNT(DISTINCT catalog_id) AS total_catalog_ids FROM products;

SELECT MIN(price) AS min, MAX(price) AS max FROM products;

SELECT MIN(price) AS min, MAX(price) AS max FROM products GROUP BY catalog_id;


SELECT id, name, price FROM products ORDER BY price DESC LIMIT 1;

SELECT AVG(price) FROM products p;

SELECT ROUND(AVG(price), 2) FROM products p;


SELECT catalog_id, ROUND(AVG(price * 1.2), 2) FROM products GROUP BY catalog_id;

SELECT SUM(price) FROM products;

SELECT catalog_id, SUM(price) FROM products GROUP BY catalog_id;
 
SELECT COUNT(*) AS total, SUBSTRING(birthday_at, 1, 3) AS decade FROM users GROUP BY decade HAVING total >= 2; 

SELECT * FROM users HAVING birthday_at >= '1990-01-01';

SELECT name, birthday_at FROM users;

INSERT INTO users (name, birthday_at) VALUES ('Светлана', '1988-02-04'), ('Олег', '1998-03-20'), ('Юлия', '2006-07-12');

SELECT * FROM users;

SELECT name, birthday_at FROM users ORDER BY birthday_at ;

SELECT YEAR(birthday_at) FROM users ORDER BY birthday_at;

SELECT YEAR(birthday_at) AS birthday_year FROM users GROUP BY birthday_year ORDER BY birthday_year;

SELECT MAX(name), YEAR(birthday_at) AS birthday_year FROM users GROUP BY birthday_year ORDER BY birthday_year;

SELECT ANY_VALUE(name), YEAR(birthday_at) AS birthday_year FROM users GROUP BY birthday_year ORDER BY birthday_year;


SELECT SUBSTRING(birthday_at, 1, 3) AS decade, COUNT(*) FROM users GROUP BY decade;

SELECT SUBSTRING(birthday_at, 1, 3) AS decade, COUNT(*) FROM users GROUP BY decade WITH ROLLUP;














-- Практическое задание по теме «Операторы, фильтрация, сортировка и ограничение»


-- Меняем  тип столбцов created_at, updated_at таблицы users с VARCHAR на DATETIME

DESC users;
SELECT * FROM users;


ALTER TABLE users MODIFY COLUMN created_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
ALTER TABLE users MODIFY COLUMN updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;


-- Заполняем created_at и updated_at 
UPDATE users SET created_at = NOW() WHERE id = 1;
UPDATE users SET created_at = NOW() WHERE id = 2;
UPDATE users SET created_at = NOW() WHERE id = 3;
UPDATE users SET created_at = NOW() WHERE id = 4;
UPDATE users SET created_at = NOW() WHERE id = 5;
UPDATE users SET created_at = NOW() WHERE id = 6;

UPDATE users SET updated_at = NOW() WHERE id = 1;
UPDATE users SET updated_at = NOW() WHERE id = 2;
UPDATE users SET updated_at = NOW() WHERE id = 3;
UPDATE users SET updated_at = NOW() WHERE id = 4;
UPDATE users SET updated_at = NOW() WHERE id = 5;
UPDATE users SET updated_at = NOW() WHERE id = 6;



TRUNCATE products; 

-- 3 Задание

INSERT INTO products
  (name, description, price, catalog_id)
VALUES
  ('Intel Core i3-8100', 'Процессор для настольных персональных компьютеров, основанных на платформе Intel.', 7890.00, 1),
  ('Intel Core i5-7400', 'Процессор для настольных персональных компьютеров, основанных на платформе Intel.', 12700.00, 1),
  ('AMD FX-8320E', 'Процессор для настольных персональных компьютеров, основанных на платформе AMD.', 4780.00, 1),
  ('AMD FX-8320', 'Процессор для настольных персональных компьютеров, основанных на платформе AMD.', 7120.00, 1),
  ('ASUS ROG MAXIMUS X HERO', 'Материнская плата ASUS ROG MAXIMUS X HERO, Z370, Socket 1151-V2, DDR4, ATX', 19310.00, 2),
  ('Gigabyte H310M S2H', 'Материнская плата Gigabyte H310M S2H, H310, Socket 1151-V2, DDR4, mATX', 4790.00, 2),
  ('MSI B250M GAMING PRO', 'Материнская плата MSI B250M GAMING PRO, B250, Socket 1151, DDR4, mATX', 5060.00, 2);


SELECT * FROM storehouses_products;
TRUNCATE storehouses_products;

INSERT INTO storehouses_products
(storehouse_id, product_id, value)
VALUES
(1, 1, 15),
(2, 1, 0),
(3, 1, 20),
(4, 1, 8),
(5, 2, 40),
(6, 2, 0),
(7, 2, 17);


SELECT * FROM storehouses_products c ORDER BY value;
SELECT * FROM storehouses_products c ORDER BY value DESC;

-- 4 задание. Извлекаем пользователей, родившихся в августе и мае.
SELECT * FROM users u ;

SELECT * FROM users WHERE id IN (3, 6);

ALTER TABLE users MODIFY COLUMN birthday_at DATE_FORMAT( '%d.%M.%Y');


SELECT name, DATE_FORMAT(birthday_at, '%d.%M.%Y') AS birthday_at FROM users;


SELECT name, DATE_FORMAT(birthday_at, '%d.%M.%Y') AS birthday_at FROM users WHERE id IN (3, 6);

-- 5 задание

SELECT * FROM catalogs WHERE id IN (5, 1, 2);


-- Практическое задание теме «Агрегация данных»

-- 1 Задание

SELECT * FROM users;

SELECT name, (TO_DAYS(NOW()) - TO_DAYS(birthday_at)) / 365.25 AS age FROM users; 
SELECT name, FLOOR((TO_DAYS(NOW()) - TO_DAYS(birthday_at)) / 365.25) AS age FROM users; 




-- 2 Задание

SELECT * FROM users;

ALTER TABLE users DROP dayname;
DELETE FROM users WHERE id = 20;


ALTER TABLE users ADD COLUMN dayweek VARCHAR (20);
ALTER TABLE users MODIFY COLUMN dayweek VARCHAR(20) AFTER birthday_at;

ALTER TABLE users RENAME COLUMN dayweek TO act_birth;

TRUNCATE users; 

INSERT INTO users (name, birthday_at, act_birth) VALUES
  ('Геннадий', '1990-10-05', '2020-10-05'),
  ('Наталья', '1984-11-12', '2020-11-12'),
  ('Александр', '1985-05-20', '2020-05-20'),
  ('Сергей', '1988-02-14', '2020-02-14'),
  ('Иван', '1998-01-12', '2020-01-12'),
  ('Мария', '2006-08-29', '2020-08-29' ),
  ('Светлана', '1988-02-04', '2020-02-04'), 
  ('Олег', '1998-03-20', '2020-03-20'), 
  ('Юлия', '2006-07-12', '2020-07-12');


 -- 3 Задание
 
 
SELECT *, DAYNAME(act_birth) as dayname FROM users;


SELECT DAYNAME(act_birth) AS dayname, COUNT(*) FROM users GROUP BY dayname; 



































